const http = require("http");
const express = require("express");
const { Server } = require("socket.io");
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
app.use(express.static("public"));
app.get("/health", (_,res)=>res.send("ok"));
io.on("connection", socket => {
  socket.emit("chat","Connected to Zombie Chaos Online");
});
server.listen(process.env.PORT || 3000, ()=>console.log("Running"));
